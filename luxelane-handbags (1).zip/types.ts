import type { Dispatch, SetStateAction } from 'react';

export interface Product {
  id: string;
  name: string;
  price: number;
  imageUrl: string;
  description: string;
  category: string;
}

export interface Category {
  id:string;
  name: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export type View = 'home' | 'adminLogin' | 'adminPanel' | 'checkout';

export interface AppContextType {
  siteName: string;
  setSiteName: Dispatch<SetStateAction<string>>;
  products: Product[];
  setProducts: Dispatch<SetStateAction<Product[]>>;
  categories: Category[];
  setCategories: Dispatch<SetStateAction<Category[]>>;
  isAdmin: boolean;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  adminEmail: string;
  updateAdminCredentials: (email?: string, password?: string) => void;
  addProduct: (product: Product) => void;
  updateProduct: (updatedProduct: Product) => void;
  deleteProduct: (productId: string) => void;
  addCategory: (category: Category) => void;
  deleteCategory: (categoryId: string) => void;
  // Cart Functions
  cart: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  // Data Import/Export
  exportSettings: () => void;
  importSettings: (file: File) => Promise<void>;
}