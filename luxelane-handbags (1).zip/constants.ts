import type { Product, Category } from './types';

export const INITIAL_SITE_NAME = 'LuxeLane Handbags';

export const INITIAL_CATEGORIES: Category[] = [
  { id: '1', name: 'All Handbags' },
  { id: '2', name: 'Tote Bags' },
  { id: '3', name: 'Crossbody Bags' },
  { id: '4', name: 'Clutches' },
  { id: '5', name: 'Shoulder Bags' },
];

// A NEW, larger, and more reliable curated list of high-quality handbag images to guarantee visibility.
export const HANDBAG_IMAGE_URLS = [
  "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1566150905458-1bf1f2997d0d?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1590779261313-22f3e8b0938f?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1547949003-9792a18a2601?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1616348436199-a91631526d42?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1579524032155-5c1a1532822a?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1622560481079-052a55985b9b?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1594223274502-94220387436b?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1591561934208-16f2c97a810c?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1559563458-527999884482?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1598533633789-a29331a6157a?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1548036328-c43584d13848?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1603513949887-a5026c0429f4?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1610290469275-ff55f042c102?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1589156172355-32a8b27f3a23?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1605733513598-a8d879956526?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1614143433989-52f20aad48a6?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1576435728678-68d0fbf94e91?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1574787293233-a2a6d5b30363?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1598532432652-538441926217?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1608667508743-33cf397b9c14?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1599819124239-b90398f86054?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1617351185343-70a225e79612?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1618011242232-35a14a04d502?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1564422171092-2435e1655294?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1587428452303-95c55ca4237c?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1600854495341-426b3bd154d6?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1601351141933-28f0ea24a49c?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1553062407-98eeb6e0e5c8?w=500&h=600&fit=crop&q=80",
  "https://images.unsplash.com/photo-1550416643-594248f2939c?w=500&h=600&fit=crop&q=80"
];


export const generateMockProducts = (count: number): Product[] => {
  const products: Product[] = [];
  const categories = INITIAL_CATEGORIES.filter(c => c.name !== 'All Handbags');
  
  const adjectives = ["Chic", "Elegant", "Stylish", "Luxury", "Classic", "Modern", "Bohemian", "Vintage", "Urban", "Sleek"];
  const materials = ["Leather", "Canvas", "Suede", "Velvet", "Woven", "Faux Fur", "Nylon", "Straw"];

  for (let i = 1; i <= count; i++) {
    const category = categories[i % categories.length];
    const bagType = category.name.slice(0, -1); // "Tote Bags" -> "Tote Bag"
    
    const adjective = adjectives[Math.floor(Math.random() * adjectives.length)];
    const material = materials[Math.floor(Math.random() * materials.length)];
    
    // Create more realistic names
    let productName = `${adjective} ${bagType}`;
    if(Math.random() > 0.5) {
        productName = `${adjective} ${material} ${bagType}`;
    }

    products.push({
      id: `prod-${Date.now()}-${i}`,
      name: productName,
      price: parseFloat((Math.random() * (300 - 50) + 50).toFixed(2)),
      // Use the reliable, curated list of images.
      imageUrl: HANDBAG_IMAGE_URLS[i % HANDBAG_IMAGE_URLS.length],
      description: `A beautifully crafted ${productName.toLowerCase()}. This ${category.name.toLowerCase()} combines style and functionality with its spacious compartments and elegant design. Made from high-quality materials, it's a must-have accessory.`,
      category: category.name,
    });
  }
  return products;
};

export const INITIAL_PRODUCTS: Product[] = generateMockProducts(120);