
import React, { useContext } from 'react';
import { AppContext } from '../context/AppContext';

const Footer: React.FC = () => {
  const { siteName } = useContext(AppContext);
  return (
    <footer className="bg-primary text-secondary">
      <div className="container mx-auto px-4 py-6 text-center">
        <p>&copy; {new Date().getFullYear()} {siteName}. All Rights Reserved.</p>
        <p className="text-xs text-gray-400 mt-2">A Frontend Demonstration Project</p>
      </div>
    </footer>
  );
};

export default Footer;
