import React, { useContext, useMemo } from 'react';
import type { Dispatch, SetStateAction } from 'react';
import { AppContext } from '../context/AppContext';
import type { View, CartItem } from '../types';
import Button from './ui/Button';

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
  setView: Dispatch<SetStateAction<View>>;
}

const Cart: React.FC<CartProps> = ({ isOpen, onClose, setView }) => {
  const { cart, removeFromCart, updateCartQuantity } = useContext(AppContext);
  
  const subtotal = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  }, [cart]);

  const handleCheckout = () => {
    onClose();
    setView('checkout');
  };

  if (!isOpen) return null;

  return (
    <>
        <div 
            className={`fixed inset-0 bg-black bg-opacity-50 z-50 transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} 
            onClick={onClose}
        ></div>
        <div className={`fixed top-0 right-0 h-full w-full max-w-md bg-white shadow-xl z-50 transform transition-transform duration-300 ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
            <div className="flex flex-col h-full">
                <div className="flex justify-between items-center p-4 border-b">
                    <h2 className="text-xl font-bold">Shopping Cart</h2>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-800 text-2xl">&times;</button>
                </div>
                
                {cart.length === 0 ? (
                    <div className="flex-grow flex flex-col justify-center items-center text-center p-4">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                        </svg>
                        <h3 className="text-lg font-semibold mt-4">Your cart is empty</h3>
                        <p className="text-gray-500 mt-1">Looks like you haven't added anything yet.</p>
                        <Button onClick={onClose} className="mt-6">Continue Shopping</Button>
                    </div>
                ) : (
                    <>
                        <div className="flex-grow overflow-y-auto p-4">
                            <ul className="divide-y divide-gray-200">
                                {cart.map(item => (
                                    <CartItemRow key={item.id} item={item} onRemove={removeFromCart} onUpdate={updateCartQuantity} />
                                ))}
                            </ul>
                        </div>
                        <div className="p-4 border-t space-y-4">
                            <div className="flex justify-between font-semibold text-lg">
                                <span>Subtotal</span>
                                <span>${subtotal.toFixed(2)}</span>
                            </div>
                            <p className="text-sm text-gray-500">Shipping and taxes calculated at checkout.</p>
                            <Button onClick={handleCheckout} className="w-full">Proceed to Checkout</Button>
                            <button onClick={onClose} className="w-full text-center text-primary font-semibold hover:underline">or Continue Shopping</button>
                        </div>
                    </>
                )}
            </div>
        </div>
    </>
  );
};

interface CartItemRowProps {
    item: CartItem;
    onRemove: (id: string) => void;
    onUpdate: (id: string, quantity: number) => void;
}

const CartItemRow: React.FC<CartItemRowProps> = ({ item, onRemove, onUpdate }) => {
    return (
        <li className="flex py-4">
            <div className="h-24 w-24 flex-shrink-0 overflow-hidden rounded-md border border-gray-200">
                <img src={item.imageUrl} alt={item.name} className="h-full w-full object-cover object-center" />
            </div>
            <div className="ml-4 flex flex-1 flex-col">
                <div>
                    <div className="flex justify-between text-base font-medium text-gray-900">
                        <h3>{item.name}</h3>
                        <p className="ml-4">${(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                </div>
                <div className="flex flex-1 items-end justify-between text-sm">
                    <div className="flex items-center border border-gray-300 rounded">
                        <button onClick={() => onUpdate(item.id, item.quantity - 1)} className="px-2 py-1 text-lg">-</button>
                        <span className="px-3 py-1">{item.quantity}</span>
                         <button onClick={() => onUpdate(item.id, item.quantity + 1)} className="px-2 py-1 text-lg">+</button>
                    </div>
                    <div className="flex">
                        <button onClick={() => onRemove(item.id)} type="button" className="font-medium text-red-600 hover:text-red-500">Remove</button>
                    </div>
                </div>
            </div>
        </li>
    )
}

export default Cart;